Extract (unzip) the files in dyloslogger20 onto your hard drive
Double click (run) DylosLogger2.0 beta.msi to install DylosLogger ver 2.0